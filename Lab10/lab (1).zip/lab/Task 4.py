def main():
	row = int(input("Enter the number of rows: "))
	column = int(input("Enter the number of column: "))
	i = 0
	j = 0
	while i < column:
		

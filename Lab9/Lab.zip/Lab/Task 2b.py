def main():
	for i in range(10,0,-1):
		string = ""
		for j in range(i):
			string +="*"
		print(string)
main()
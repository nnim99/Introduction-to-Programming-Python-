def main():
	string = ""
	for i in range(10):
		string +="*"
		print(string)
main()
def main():
	shoppingList = []
	item01       = input("Enter first item: ")
	item02       = input("Enter second item: ")
	item03       = input("Enter third item: ")
	item04       = input("Enter fourth item: ")
	item05       = input("Enter fifth item: ")
	shoppingList.append(item01)
	shoppingList.append(item02)
	shoppingList.append(item03)
	shoppingList.append(item04)
	shoppingList.append(item05)
	print("The shopping list: " ,shoppingList)
main()
